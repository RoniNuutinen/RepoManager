// executes operation according to input,
// assuming input is valid
enum command operate(enum command operation, const char * cmd_param_1, const char * cmd_param_2);